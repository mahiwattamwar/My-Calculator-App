package com.maheshwattamwar.mycalculatorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class About extends AppCompatActivity {
    Button contact;
    ImageButton linkedin,git,insta;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        contact = findViewById(R.id.contact);
        linkedin = findViewById(R.id.linkedin);
        git = findViewById(R.id.git);
        insta = findViewById(R.id.insta);
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url="https://mahiwattamwar.github.io/";
                Intent abc=new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(abc);
            }
        });


        linkedin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String li="https://www.linkedin.com/in/maheshwattamwar/";
                Intent abc=new Intent(Intent.ACTION_VIEW, Uri.parse(li));
                startActivity(abc);
            }
        });

        git.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String git="https://github.com/mahiwattamwar";
                Intent abc=new Intent(Intent.ACTION_VIEW, Uri.parse(git));
                startActivity(abc);
            }
        });
        insta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String insta="https://www.instagram.com/mr.maheshwattamwar/";
                Intent abc=new Intent(Intent.ACTION_VIEW, Uri.parse(insta));
                startActivity(abc);
            }
        });
    }

}